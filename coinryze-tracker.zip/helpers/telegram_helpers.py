# Telegram helper functions
