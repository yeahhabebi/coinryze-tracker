# R2 helper functions
