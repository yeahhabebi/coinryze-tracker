# CoinRyze Tracker

Full Streamlit dashboard tracking color/number signals from Telegram and saving to Cloudflare R2.
